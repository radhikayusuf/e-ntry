/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.entry.controller;

import com.app.entry.controller.AddTransactionController.AddTrasactionContract;
import com.app.entry.model.AddTransactionModel;
import com.app.entry.utils.base.BaseContract;
import com.app.entry.utils.base.BaseController;
import java.util.List;

/**
 *
 * @author radhikayusuf
 */
public class AddTransactionController extends BaseController<AddTrasactionContract>{

    AddTransactionModel mModel = new AddTransactionModel();
    
    public AddTransactionController(AddTrasactionContract contract) {
        super(contract);
    }
    
    public List<String[]> getDataStudio(){
        return mModel.getStudio();
    }

    public void tambahData(String nama, String noTelp, String jmlOrang, String jenisPaket, String idStudio) {
        System.out.println(nama + " - " + noTelp + " - " + jmlOrang + " - " +jenisPaket + " - " +idStudio);
        mModel.postData(nama, noTelp, jmlOrang, jenisPaket, idStudio);
    }
    
    public interface AddTrasactionContract extends BaseContract{
        
    }
    
}
