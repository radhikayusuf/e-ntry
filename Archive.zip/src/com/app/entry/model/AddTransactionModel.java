/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.entry.model;

import com.app.entry.EntryApplication;
import com.app.entry.utils.base.BaseModel;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author radhikayusuf
 */
public class AddTransactionModel extends BaseModel {
    
    public AddTransactionModel() {
        super("tb_transaksi");
    }
    
    public List<String[]> getStudio(){
        try {
            String sql = "SELECT `id_studio` as `id`, `nama_studio` as `Nama Studio`FROM tb_studio WHERE id_photographer IS NOT NULL;";
            java.sql.Connection conn = (Connection) mConnection;
            java.sql.Statement stm = conn.createStatement();            
            ResultSet set = stm.executeQuery(sql);           
            List<String[]> result = new ArrayList<>();                        
            while(set.next()){
                result.add(new String[]{set.getString(1), set.getString(2)});                
            }
            
            return result;
        } catch (SQLException ex) {
            Logger.getLogger(AntrianModel.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
        
    }
    
    
    public boolean postData(String nama, String noTelp, String jmlOrang, String jenisPaket, String idStudio){
        try {
            String sql = "INSERT INTO tb_user(nama_user, no_telp) VALUES("+nama+", "+noTelp+");\n";
            String sql1 = "SELECT `id_user` INTO @id_user FROM tb_user WHERE `nama_user` = "+nama+" AND `no_telp` = "+noTelp+" ORDER BY `id_user` DESC LIMIT 1;\n";
            String sql2 = "INSERT INTO tb_transaksi(total_cost, jenis_paket, id_user, id_kasir) VALUES(getPrice('"+jenisPaket+"'), "+jenisPaket+", @id_user, "+EntryApplication.ID_KASIR+");\n";
            String sql3 = "SELECT `no_antrian` INTO @latest_antrian FROM tb_antrian ORDER BY `id_antrian` DESC LIMIT 1;\n";
            String sql4 = "SELECT `id_transaksi` INTO @id_transaksi FROM tb_transaksi ORDER BY `id_transaksi` DESC LIMIT 1;\n" ;
            String sql5 = "SET @latest_antrian = @latest_antrian + 1;\n";
            String sql6 = "INSERT INTO tb_antrian(no_antrian, durasi, waktu_mulai, waktu_selesai, jumlah_orang, id_transaksi, id_studio) VALUES(@latest_antrian, 0, null, null, "+jmlOrang+", @id_transaksi, "+idStudio+");";
            
            
            System.out.println(sql1 + "\n" + sql2 + "\n" +sql3 + "\n" +sql4 + "\n" +sql5 + "\n" +sql6);
            java.sql.Connection conn = (Connection) mConnection;
            java.sql.Statement stm = conn.createStatement();            
            stm.addBatch(sql);
            stm.addBatch(sql2);
            stm.addBatch(sql3);
            stm.addBatch(sql4);
            stm.addBatch(sql5);
            stm.addBatch(sql6);
            
            
            stm.executeBatch();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(AntrianModel.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    
    
    
}
